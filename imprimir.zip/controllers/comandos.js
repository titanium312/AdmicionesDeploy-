const { agentes } = require('./agentes');
const colas = new Map(); // cada agente tiene su lista de comandos

function enviarComando(req, res) {
  const { agentId, comando } = req.body || {};
  if (!agentId) return res.status(400).json({ error: 'Falta agentId' });
  if (!comando || typeof comando !== 'string') return res.status(400).json({ error: 'Falta comando' });

  const orden = { id: Date.now().toString(), comando, fecha: new Date().toISOString() };
  const cola = colas.get(agentId) || [];
  cola.push(orden);
  colas.set(agentId, cola);

  res.json({ exito: true, orden });
}

function obtenerSiguiente(req, res) {
  const { agentId } = req.query;
  if (!agentId) return res.status(400).json({ error: 'Falta agentId' });
  const cola = colas.get(agentId) || [];
  const siguiente = cola.shift();
  colas.set(agentId, cola);
  if (!siguiente) return res.json({ mensaje: 'Sin comandos pendientes' });
  res.json(siguiente);
}

function verCola(req, res) {
  const { id } = req.params;
  const cola = colas.get(id) || [];
  res.json({ id, pendientes: cola });
}

module.exports = { enviarComando, obtenerSiguiente, verCola, colas };
