// resultados.js (versión temporal)
const resultados = new Map(); // resultados por agente (en memoria)

function guardarResultado(req, res) {
  const {
    agentId,
    comando,
    command,
    salida,
    error,
    codigo
  } = req.body || {};

  // Acepta 'command' o 'comando'
  const cmd = comando || command;
  if (!agentId || !cmd) {
    return res.status(400).json({ error: 'Datos incompletos: se requiere agentId y comando' });
  }

  const lista = resultados.get(agentId) || [];
  const entrada = {
    comando: cmd,
    salida: salida ?? null,
    error: error ?? null,
    codigo: Number.isFinite(codigo) ? codigo : 0,
    fecha: new Date().toISOString()
  };

  lista.push(entrada);
  if (lista.length > 50) lista.shift(); // límite máximo
  resultados.set(agentId, lista);

  res.json({ exito: true, guardado: entrada });
}

function verHistorial(req, res) {
  const { id } = req.params;
  res.json(resultados.get(id) || []);
}

module.exports = { guardarResultado, verHistorial, resultados };
