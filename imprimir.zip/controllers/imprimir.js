// controllers/colaImpresion.js
const path = require('path');
const fs = require('fs');

const colasImpresion = new Map(); // cola por agente

// --- helpers ---
function isPdf(file) {
  return typeof file === 'string' && file.toLowerCase().endsWith('.pdf');
}

function normalizarOpciones(opciones = {}) {
  return {
    duplex: !!opciones.duplex,
    orientacion: opciones.orientacion === 'landscape' ? 'landscape' : 'portrait',
    escala: opciones.escala === 'noscale' ? 'noscale' : 'fit',
  };
}

/**
 * POST /Imprimir/cola/encolar
 * body: { agentId, ruta, impresora, opciones? }
 */
function encolarImpresion(req, res) {
  const { agentId, ruta, impresora, opciones = {} } = req.body || {};

  if (!agentId || typeof agentId !== 'string') {
    return res.status(400).json({ error: 'Falta agentId' });
  }
  if (!ruta || !isPdf(ruta)) {
    return res.status(400).json({ error: 'Envíe "ruta" a un .pdf válido' });
  }
  if (!impresora || typeof impresora !== 'string' || !impresora.trim()) {
    return res.status(400).json({ error: 'Envíe "impresora" (nombre exacto de Windows)' });
  }

  const absPdf = path.resolve(ruta);
  // validación ligera (no bloqueante si no existe)
  try {
    fs.accessSync(absPdf, fs.constants.R_OK);
  } catch {
    // si prefieres permitir encolar aunque aún no exista físicamente, comenta este return:
    return res.status(400).json({ error: 'El PDF no existe o no es accesible' });
  }

  const job = {
    id: Date.now().toString(),
    tipo: 'imprimir-pdf',
    payload: {
      ruta: absPdf,
      impresora: impresora.trim(),
      opciones: normalizarOpciones(opciones),
    },
    fecha: new Date().toISOString(),
  };

  const cola = colasImpresion.get(agentId) || [];
  cola.push(job);
  colasImpresion.set(agentId, cola);

  res.json({ exito: true, job });
}

/**
 * GET /Imprimir/cola/siguiente?agentId=...
 * Devuelve y saca de la cola el siguiente trabajo de impresión del agente
 */
function siguienteImpresion(req, res) {
  const { agentId } = req.query || {};
  if (!agentId) return res.status(400).json({ error: 'Falta agentId' });

  const cola = colasImpresion.get(agentId) || [];
  const siguiente = cola.shift();
  colasImpresion.set(agentId, cola);

  if (!siguiente) return res.json({ mensaje: 'Sin trabajos de impresión pendientes' });
  res.json(siguiente);
}

/**
 * GET /Imprimir/cola/:id
 * Ver la cola completa de un agente
 */
function verColaImpresion(req, res) {
  const { id } = req.params || {};
  const cola = colasImpresion.get(id) || [];
  res.json({ id, pendientes: cola });
}

/**
 * (Opcional) DELETE /Imprimir/cola/:agentId/:jobId
 * Cancelar un job en cola
 */
function cancelarJob(req, res) {
  const { agentId, jobId } = req.params || {};
  if (!agentId || !jobId) return res.status(400).json({ error: 'Falta agentId o jobId' });
  const cola = colasImpresion.get(agentId) || [];
  const nueva = cola.filter(j => j.id !== jobId);
  colasImpresion.set(agentId, nueva);
  res.json({ exito: true, eliminados: cola.length - nueva.length });
}

module.exports = {
  encolarImpresion,
  siguienteImpresion,
  verColaImpresion,
  cancelarJob,
  colasImpresion, // por si quieres inspeccionarlo desde otros módulos
};
