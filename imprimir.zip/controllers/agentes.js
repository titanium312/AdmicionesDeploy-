const agentes = new Map();

function registrarAgente(info, req) {
  const ahora = new Date().toISOString();
  const { agentId, nombre, sistema } = info || {};
  if (!agentId) return null;

  const previo = agentes.get(agentId) || {};
  const nuevo = {
    id: agentId,
    nombre: nombre ?? previo.nombre ?? 'sin nombre',
    sistema: sistema ?? previo.sistema ?? null,
    ultimaConexion: ahora,
    ip: req.ip,
    navegador: req.headers['user-agent'] || null,
  };

  agentes.set(agentId, nuevo);
  return nuevo;
}

function listarAgentes(req, res) {
  res.json(Array.from(agentes.values()));
}

module.exports = { registrarAgente, listarAgentes, agentes };
