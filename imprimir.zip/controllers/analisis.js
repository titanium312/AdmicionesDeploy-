const { resultados } = require('./resultados');

function resumen(req, res) {
  const info = [];
  for (const [id, lista] of resultados.entries()) {
    const total = lista.length;
    const errores = lista.filter(x => x.codigo !== 0).length;
    const ultimo = lista[lista.length - 1] || {};
    info.push({ id, total, errores, ultimo });
  }
  res.json(info);
}

function comandosMasUsados(req, res) {
  const contador = {};
  for (const lista of resultados.values()) {
    for (const r of lista) {
      const base = r.comando.split(' ')[0];
      contador[base] = (contador[base] || 0) + 1;
    }
  }
  const top = Object.entries(contador)
    .map(([cmd, cantidad]) => ({ cmd, cantidad }))
    .sort((a, b) => b.cantidad - a.cantidad)
    .slice(0, 10);
  res.json(top);
}

module.exports = { resumen, comandosMasUsados };
