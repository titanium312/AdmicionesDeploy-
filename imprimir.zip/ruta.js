// router.js
const express = require('express');
const imprimir = express.Router();

// Si tu app principal NO hace app.use(express.json()), deja esta línea:
imprimir.use(express.json());

// Controladores
const { registrarAgente, listarAgentes } = require('./controllers/agentes');
const { enviarComando, obtenerSiguiente, verCola } = require('./controllers/comandos');
const { guardarResultado, verHistorial } = require('./controllers/resultados');
const { resumen, comandosMasUsados } = require('./controllers/analisis');
// 👇 Descomenta estas 2 líneas si tienes esos controladores y quieres exponer sus rutas
const {
  encolarImpresion,
  siguienteImpresion,
  verColaImpresion,
  cancelarJob
} = require('./controllers/imprimir');
// (Elimina) const { } = require('./controllers/imprimir');

/* ==================== AGENTES ==================== */

// POST /Imprimir/agentes/registrar
imprimir.post('/agentes/registrar', (req, res) => {
  const registro = registrarAgente(req.body, req);
  if (!registro) return res.status(400).json({ error: 'Falta agentId' });
  res.json(registro);
});

// GET /Imprimir/agentes
imprimir.get('/agentes', listarAgentes);

/* ==================== COMANDOS ==================== */

// POST /Imprimir/comando
imprimir.post('/comando', enviarComando);

// GET /Imprimir/siguiente?agentId=...&nombre=...
imprimir.get('/siguiente', (req, res) => {
  registrarAgente({ agentId: req.query.agentId, nombre: req.query.nombre }, req);
  obtenerSiguiente(req, res);
});

// GET /Imprimir/agentes/:id/cola
imprimir.get('/agentes/:id/cola', verCola);

/* ==================== RESULTADOS ==================== */

// POST /Imprimir/resultado
imprimir.post('/resultado', guardarResultado);

// GET /Imprimir/historial/:id
imprimir.get('/historial/:id', verHistorial);

// GET /Imprimir/historial?agentId=...
imprimir.get('/historial', (req, res) => {
  const { agentId } = req.query || {};
  if (!agentId) return res.status(400).json({ error: 'Falta agentId' });
  req.params = { id: agentId };
  verHistorial(req, res);
});

/* ==================== ANÁLISIS ==================== */

// GET /Imprimir/analisis/resumen
imprimir.get('/analisis/resumen', resumen);

// GET /Imprimir/analisis/top
imprimir.get('/analisis/top', comandosMasUsados);

/* ==================== IMPRESIÓN (opcional) ==================== */
// Encolar un trabajo de impresión PDF
imprimir.post('/Imprimir/cola/encolar', encolarImpresion);

// Obtener el siguiente trabajo de impresión para un agente
imprimir.get('/Imprimir/cola/siguiente', siguienteImpresion);

// Ver cola de un agente
imprimir.get('/Imprimir/cola/:id', verColaImpresion);

// (Opcional) Cancelar un job de la cola
imprimir.delete('/Imprimir/cola/:agentId/:jobId', cancelarJob);

module.exports = imprimir;
